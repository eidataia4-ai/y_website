موقع شخصي عربي — دليل التشغيل والنشر

1) افتح index.html في المتصفح لمعاينة الموقع.
2) عدّل [اكتب اسمك هنا] والنبذة والمهارات والمشاريع في index.html.
3) غيّر your-email@example.com إلى بريد مخصص للتواصل، أو احذف زر البريد.
4) ارفع الملفات الثلاثة (index.html وstyle.css وscript.js) إلى مستودع GitHub عام.
5) من المستودع افتح Settings ثم Pages.
6) في Build and deployment اختر Deploy from a branch.
7) اختر Branch: main والمجلد: /(root)، ثم Save.
8) انتظر اكتمال النشر. سيظهر رابط مثل https://USERNAME.github.io/REPOSITORY/
9) من Settings > Pages فعّل Enforce HTTPS إذا ظهر الخيار.

ملاحظات:
- GitHub Pages مناسب للمواقع الثابتة ولا يشغّل خادم Node.js أو قواعد بيانات.
- شهادة HTTPS تُدار تلقائيًا من GitHub Pages بعد تجهيز النشر والدومين.
- لا تضع كلمات مرور أو بيانات خاصة في ملفات الموقع العامة.
